#include "wav.h"

// Funciones utilitarias de transformaci�n entre formatos

//Ojo, el tama�o debe ser par>=2
void transformarBuffer16a8(char buffer[],unsigned *tam){
	unsigned i,j;
	for(i=0,j=1;j<*tam;i++,j=j+2){
		buffer[i]=buffer[j];
	}
	*tam=(*tam)>>1; //*tam/2
}

//Ojo, el tama�o no debe ser > 32768
void transformarBuffer8a16(char buffer[],unsigned *tam){
	unsigned i;
	long j;

	for(i=((*tam)<<1)-2,j=*tam;j>=0;i=i-2,j--){
		buffer[i]=0;
		buffer[i+1]=buffer[j];
	}
	*tam=(*tam)<<1; //*tam*2
}

void sacaValoresInversosBuffer(char buffer[],unsigned tam,unsigned tamDato){

	unsigned i;
	for(i=0;i<tam;i=i+tamDato) buffer[i]=buffer[i]+128;
}

//Separa los canales intercalados de un wav de un buffer a 2 bufferes
void separaCanalesBuffer(char buffer[],unsigned tam,
								 char bufferCanal1[],unsigned *tamCanal1,
								 char bufferCanal2[],unsigned *tamCanal2,
								 unsigned tamDatoEnBytes){

	unsigned i,j,k;

	for(i=0,j=0;i<tam;j=j+tamDatoEnBytes){
		for(k=0;k<tamDatoEnBytes;k++,i++){
			bufferCanal1[j+k]=buffer[i];
		}
		for(k=0;k<tamDatoEnBytes;k++,i++){
			bufferCanal2[j+k]=buffer[i];
		}
	}
	*tamCanal1=tam>>1;
	*tamCanal2=tam>>1;
}

//Junta los canales intercalados de un wav de un buffer a 2 bufferes
//el tama�o del canal debe ser < 32768
void juntaCanalesBuffer(char buffer[],unsigned *tam,
								 char bufferCanal1[],char bufferCanal2[],
								 unsigned tamDatoEnBytes){

	unsigned i,j,k;

	for(i=0,j=0;i<*tam;i=i+tamDatoEnBytes){
		for(k=0;k<tamDatoEnBytes;k++,j++){
			buffer[j+k]=bufferCanal1[i];
		}
		for(k=0;k<tamDatoEnBytes;k++,j++){
			buffer[j+k]=bufferCanal2[i];
		}
	}
	*tam=(*tam)<<1;
}

char guardarDatosWavVocMonoFP(FILE *f_in,FILE *f_out,unsigned long amplitud,unsigned short bitsMuestra){
	char          error=0;
	char          *bufferOut;
	unsigned      bytesBufferOut;
	unsigned long i,tamBuffer=2048;

	bufferOut=new char [tamBuffer];
	if(bufferOut){
		for(i=0,bytesBufferOut=1;i<amplitud && bytesBufferOut>0;i=i+tamBuffer/2){
			bytesBufferOut=fread(bufferOut,sizeof(char),tamBuffer/2,f_in);
			if(bytesBufferOut>0){
				if(bitsMuestra==8) sacaValoresInversosBuffer(bufferOut,bytesBufferOut,bitsMuestra>>3);
				fwrite(bufferOut,sizeof(char),bytesBufferOut,f_out);
			}
		}
	}
	else error=2;
	if(bufferOut) delete bufferOut;

	return(error);
}

char guardarDatosWavVocEstereoFP(FILE *f_in1,FILE *f_in2,FILE *f_out,unsigned long amplitud,unsigned short bitsMuestra){

	char          error=0;
	char          *bufferOut,*bufferIn1,*bufferIn2;
	unsigned      bytesBufferOut,bytesBufferIn1,bytesBufferIn2;
	unsigned long i,tamBuffer=2048;

	bufferOut=new char [tamBuffer];
	bufferIn1=new char [tamBuffer];
	bufferIn2=new char [tamBuffer];
	if(bufferOut && bufferIn1 && bufferIn2){
		for(i=0,bytesBufferIn1=1,bytesBufferIn2=1;i<amplitud && bytesBufferIn1>0 && bytesBufferIn2>0;i=i+tamBuffer/2){
			bytesBufferIn1=fread(bufferIn1,sizeof(char),tamBuffer/2,f_in1);
			bytesBufferIn2=fread(bufferIn2,sizeof(char),tamBuffer/2,f_in2);
			if(bytesBufferIn1>0 && bytesBufferIn2>0){
				if(bytesBufferIn1<bytesBufferIn2) bytesBufferOut=bytesBufferIn1;
				else bytesBufferOut=bytesBufferIn2;
				juntaCanalesBuffer(bufferOut,&bytesBufferOut,bufferIn1,bufferIn2,bitsMuestra>>3);
				if(bitsMuestra==8) sacaValoresInversosBuffer(bufferOut,bytesBufferOut,bitsMuestra>>3);
				fwrite(bufferOut,sizeof(char),bytesBufferOut,f_out);
			}
		}
	}
	else error=2;
	if(bufferOut) delete bufferOut;
	if(bufferIn1) delete bufferIn1;
	if(bufferIn2) delete bufferIn2;

	return(error);
}


// VOC
void rellenaCabVoc(CAB_VOC *voc,unsigned long tamCanal,
								unsigned long frecuencia,
								unsigned short numCanales,unsigned bitsMuestra){
	unsigned i;
	unsigned long tam;

	memcpy(voc->cID,"Creative Voice File",19);
	voc->otrosDatos[0]=0x1a;
	voc->otrosDatos[1]=0x1a;
	voc->otrosDatos[2]=0x00;
	voc->otrosDatos[3]=0x14;
	voc->otrosDatos[4]=0x01;
	voc->otrosDatos[5]=0x1f;
	voc->otrosDatos[6]=0x11;
	voc->otrosDatos[7]=0x09;

	tam=(tamCanal*numCanales*bitsMuestra/8)+12;
	voc->tamVoc[0]=(unsigned char)tam;
	voc->tamVoc[1]=(unsigned char)(tam>>8);
	voc->tamVoc[2]=(unsigned char)(tam>>16);

	voc->muestrasPorSeg=frecuencia;
	voc->numCanales=(char)numCanales;
	voc->bitsMuestra=(char)bitsMuestra;

	for(i=0;i<6;i++) voc->otrosDatos1[i]=0;
}

char transformaSmpAVoc(char fichero[],char canal1[],char canal2[],
							  unsigned short numCanales,unsigned long frecuencia,
							  unsigned short bitsMuestra){


	char          error;
	unsigned long amplitud,amplitudAux;
	CAB_VOC       voc;
	FILE          *f_in1,*f_in2,*f_out;

	error=0;
	if(numCanales==2 && !estaFichero(canal2)) error=1;
	if(numCanales==1 && !estaFichero(canal1)) error=1;

	if(!error){
		switch(numCanales){
			case 1:	f_out=fopen(fichero,"wb+");
						f_in1=fopen(canal1,"rb");
						if(f_out!=NULL && f_in1!=NULL){
							amplitud=fileSize(canal1);
							rellenaCabVoc(&voc,amplitud,frecuencia,numCanales,bitsMuestra);
							fwrite(&voc,sizeof(CAB_VOC),1,f_out);

							error=guardarDatosWavVocMonoFP(f_in1,f_out,amplitud,bitsMuestra);
							fputc(0,f_out);
						}
						else error=1;
						fclose(f_out);
						break;
			case 2: f_out=fopen(fichero,"wb+");
					  f_in1=fopen(canal1,"rb");
					  f_in2=fopen(canal2,"rb");
					  if(f_out!=NULL && f_in1!=NULL && f_in2!=NULL){
							amplitudAux=fileSize(canal1);
							amplitud=fileSize(canal2);
							if(amplitudAux<amplitud) amplitud=amplitudAux;
							rellenaCabVoc(&voc,amplitud,frecuencia,numCanales,bitsMuestra);
							fwrite(&voc,sizeof(CAB_VOC),1,f_out);

							error=guardarDatosWavVocEstereoFP(f_in1,f_in2,f_out,amplitud,bitsMuestra);
							fputc(0,f_out);
					  }
					  else error=1;
					  fclose(f_out);
					  fclose(f_in1);
					  fclose(f_in2);
					  break;
		}
	}
	return(error);
}

//WAV

void rellenaCabEtiquetaWav(CAB_ETIQUETA_WAV *wav,unsigned long tamEtiqueta){
	memcpy(wav->dID,"DISP",4);
	wav->tamCabEtiqueta=tamEtiqueta+4;
	wav->tipo=1;
}
void rellenaCabInfoWav(CAB_INFO_WAV *wav,unsigned long tamDescripcion){
	memcpy(wav->lID,"LIST",4);
	wav->tamCabList=0x16;
	memcpy(wav->iID,"INFOISBJ",8);
	wav->tamCabDesc=tamDescripcion;
}
void rellenaCabWav(CAB_WAV *wav,unsigned long tamCanal,
								unsigned long frecuencia,
								unsigned short numCanales,unsigned bitsMuestra){

	memcpy(wav->rID,"RIFF",4);

	wav->tamWav=(tamCanal*(numCanales*bitsMuestra/8))+89; //tama�o wave

	memcpy(wav->wID,"WAVE",4);
	memcpy(wav->fID,"fmt ",4);

	wav->tamFormato=16;
	wav->tipoFormato=1;
	wav->numCanales=numCanales;
	wav->muestrasPorSeg=frecuencia;
	wav->bytesPorSeg=frecuencia*(numCanales*bitsMuestra/8);
	wav->alineacionBloque=(numCanales*bitsMuestra/8);
	wav->bitsMuestra=bitsMuestra;

	memcpy(wav->dID,"data",4);

	wav->tamDatos=tamCanal*(numCanales*bitsMuestra/8);

}
char cargaCabeceraWavFichero(CAB_WAV *wav,char fichero[]){

	char lee;
	FILE *f;

	f=fopen(fichero,"rb");
	if(f!=NULL){
		lee=1;

		fseek(f,0, SEEK_SET);

		leeCadenaFp(wav->rID,4,f);
		wav->tamWav=leeLongFp(f);
		leeCadenaFp(wav->wID,4,f);
		leeCadenaFp(wav->fID,4,f);

		wav->tamFormato       =leeLongFp(f);
		wav->tipoFormato      =leeIntFp(f);
		wav->numCanales       =leeIntFp(f);
		wav->muestrasPorSeg   =leeLongFp(f);
		wav->bytesPorSeg      =leeLongFp(f);
		wav->alineacionBloque =leeIntFp(f);
		wav->bitsMuestra      =leeIntFp(f);

		fseek(f,(wav->tamFormato-16),SEEK_CUR); //Salto los dem�s datos si los hay.
		leeCadenaFp(wav->dID,4,f);
		wav->tamDatos=leeLongFp(f);
	}
	else lee=0;
	fclose(f);
	return(lee);
}


void imprimeDescripcionWavFichero(FILE *f,char etiqueta[],char info[]){
	unsigned long    tamEtiqueta,tamInfo;
	CAB_INFO_WAV     cabInfo;
	CAB_ETIQUETA_WAV cabEtiqueta;

	tamEtiqueta=strlen(etiqueta);
	tamInfo=strlen(info);

	rellenaCabEtiquetaWav(&cabEtiqueta,tamEtiqueta);
	fwrite(&cabEtiqueta,sizeof(CAB_ETIQUETA_WAV),1,f);
	fwrite(etiqueta,sizeof(char),tamEtiqueta,f);
	rellenaCabInfoWav(&cabInfo,tamInfo);
	fwrite(&cabInfo,sizeof(CAB_INFO_WAV),1,f);
	fwrite(info,sizeof(char),tamInfo,f);

}




char esWavValido(CAB_WAV *wav){
	return(memcmp(wav->rID,"RIFF",4)==0 && memcmp(wav->wID,"WAVE",4)==0
			 && memcmp(wav->fID,"fmt ",4)==0 && memcmp(wav->dID,"data",4)==0);
}

char esWavCompatible(CAB_WAV *wav){
	return ((wav->numCanales==1 || wav->numCanales==2) &&
			  (wav->bitsMuestra==8 || wav->bitsMuestra==16));

}


char transformaSmpAWav(char fichero[],char canal1[],char canal2[],
							  unsigned short numCanales,unsigned long frecuencia,
							  unsigned short bitsMuestra){


	char          error;
	unsigned long amplitud,amplitudAux;
	CAB_WAV       wav;
	FILE          *f_in1,*f_in2,*f_out;

	error=0;
	if(numCanales==2 && !estaFichero(canal2)) error=1;
	if(numCanales==1 && !estaFichero(canal1)) error=1;

	if(!error){
		switch(numCanales){
			case 1:	f_out=fopen(fichero,"wb+");
						f_in1=fopen(canal1,"rb");
						if(f_out!=NULL && f_in1!=NULL){
							amplitud=fileSize(canal1);
							rellenaCabWav(&wav,amplitud,frecuencia,numCanales,bitsMuestra);
							fwrite(&wav,sizeof(CAB_WAV),1,f_out);

							error=guardarDatosWavVocMonoFP(f_in1,f_out,amplitud,bitsMuestra);
						}
						else error=1;
						fclose(f_out);
						break;
			case 2: f_out=fopen(fichero,"wb+");
					  f_in1=fopen(canal1,"rb");
					  f_in2=fopen(canal2,"rb");
					  if(f_out!=NULL && f_in1!=NULL && f_in2!=NULL){
							amplitudAux=fileSize(canal1);
							amplitud=fileSize(canal2);
							if(amplitudAux<amplitud) amplitud=amplitudAux;
							rellenaCabWav(&wav,amplitud,frecuencia,numCanales,bitsMuestra);
							fwrite(&wav,sizeof(CAB_WAV),1,f_out);

							error=guardarDatosWavVocEstereoFP(f_in1,f_in2,f_out,amplitud,bitsMuestra);
					  }
					  else error=1;
					  fclose(f_out);
					  fclose(f_in1);
					  fclose(f_in2);
					  break;
		}
	}
	return(error);
}


char transformaWavASmp(char fichero[],char canal1[],char canal2[],char modo){
	char          error=0;
	char          *buffer,*buffer1,*buffer2;
	unsigned      bytes,bytesBuffer1,bytesBuffer2;
	unsigned long i;
	unsigned long tamBuffer=2048;
	CAB_WAV       wav;
	FILE          *f_in,*f_out1,*f_out2;

	if(!cargaCabeceraWavFichero(&wav,fichero)) error=1;
	else if(!esWavValido(&wav))  error=2;
	else if(!esWavCompatible(&wav))  error=3;
	else{
		f_in=fopen(fichero,"rb");
		f_out1=fopen(canal1,"wb+");
		if(wav.numCanales==2) f_out2=fopen(canal2,"wb+");
		if(f_in!=NULL && f_out1!=NULL || (wav.numCanales==2 && f_out1!=NULL &&  f_out2!=NULL)){
			fseek(f_in,wav.tamFormato+28,SEEK_SET);
			switch(wav.numCanales){
				case 1: buffer=new char [tamBuffer];
						  if(buffer){
							  for(i=0,bytes=1;i<wav.tamDatos && bytes>0;i=i+tamBuffer/2){
									bytes=fread(buffer,sizeof(char),tamBuffer/2,f_in);
									if(bytes>0){

										if((i+tamBuffer/2)>wav.tamDatos) bytes=wav.tamDatos-i;
										if(wav.bitsMuestra==16 && modo==0) transformarBuffer16a8(buffer,&bytes);
										else if(wav.bitsMuestra==8 && modo==1) transformarBuffer8a16(buffer,&bytes);
										if(wav.bitsMuestra==8) sacaValoresInversosBuffer(buffer,bytes,modo+1);
										fwrite(buffer,sizeof(char),bytes,f_out1);
									}
							  }
							  delete buffer;
						  }
						  break;
				case 2: buffer=new char [tamBuffer];
						  if(buffer){
							  buffer1=new char [tamBuffer];
							  buffer2=new char [tamBuffer];
							  if(buffer1 && buffer2){
									for(i=0,bytes=1;i<wav.tamDatos && bytes>0;i=i+tamBuffer/2){
										bytes=fread(buffer,sizeof(char),tamBuffer/2,f_in);
										if(bytes>0){
											if((i+tamBuffer/2)>wav.tamDatos) bytes=wav.tamDatos-i;
											separaCanalesBuffer(buffer,bytes,buffer1,&bytesBuffer1,buffer2,&bytesBuffer2,wav.bitsMuestra>>3);

											if(wav.bitsMuestra==16 && modo==0) transformarBuffer16a8(buffer1,&bytesBuffer1);
											else if(wav.bitsMuestra==8 && modo==1) transformarBuffer8a16(buffer1,&bytesBuffer1);
											if(wav.bitsMuestra==8) sacaValoresInversosBuffer(buffer1,bytesBuffer1,modo+1);
											fwrite(buffer1,sizeof(char),bytesBuffer1,f_out1);

											if(wav.bitsMuestra==16 && modo==0) transformarBuffer16a8(buffer2,&bytesBuffer2);
											else if(wav.bitsMuestra==8 && modo==1) transformarBuffer8a16(buffer2,&bytesBuffer2);
											if(wav.bitsMuestra==8) sacaValoresInversosBuffer(buffer2,bytesBuffer2,modo+1);
											fwrite(buffer2,sizeof(char),bytesBuffer2,f_out2);
										}
									}
							  }
							  if(buffer1) delete buffer1;
							  if(buffer2) delete buffer2;
							  if(buffer) delete buffer;
						  }

						  break;
			}
		}
		else error=1;
		fclose(f_in);
		fclose(f_out1);
		if(wav.numCanales==2) fclose(f_out2);

	}
	return(error);
}