#ifndef _CCUADRO_LISTA.H
#define _CCUADRO_LISTA.H

	#include "cobjgraf.h"
	#include "tvcadena.h"

	#define CCUADRO_LISTA_SINSELECCION   0
	#define CCUADRO_LISTA_UNISELECCION   1
	#define CCUADRO_LISTA_MULTISELECCION 2


	class CCuadroLista : public CObjetoGrafico{
		public:
			CCuadroLista();
			~CCuadroLista();

			// M�todos estandar
			void inicializar();//inicializa el objeto con unos valores predeterminados
			void activar();    //activa el objeto (procesa datos de entrada)
			void desactivar(); //desactiva el objeto (no procesa datos de entrada)
			void enfocar();    //pone el foco (habilita la entrada por teclado)
			void desenfocar(); //quita el foco (no habilita la entrada por teclado)
			void refrescar();  //actualiza y pinta el objeto (si no esta oculto)
			void actualizar(); //actualiza datos internos pero no pinta
			void pintar();     //repinta el objeto seg�n sus datos internos
			void procesar();   //procesa los datos de entrada (raton y teclado)
			void mostrar();    //activa y muestra el objeto
			void ocultar();    //desactiva y oculta el objeto

			//Variables configurables (lectura/escritura)
			int			 colorFondo;				 //Color de fondo
			int   		 colorPrimerPlano;		 //Color de primerPlano
			int			 colorFondoSeleccion;	 //Color de fondo del item seleccionado
			int          colorOcultacion;        //Color con el que se oculta
			BOOL			 tipo3d;						 //Tipo 3d
			BOOL			 texto3d;					 //Texto en relieve
			int          tamFuente;					 //Tama�o fuente texto
			BOOL         conRecuadro;            //Indica si est� delimitado por un recuadro.

			int          tipoSeleccion;          //Tipo de seleccion
			BOOL			 tipoAutoScroll;			 //Tipo autoscroll
			BOOL         seleccionSinPulsacion;  //La selecci�n se realiza sin hacer pulsar el item
			unsigned     xSeleccion,x1Seleccion; //Posiciones de resalte en vector
			int			 posXSeleccion,posX1Seleccion; //Posiciones X del resalte

			// M�todos propios
			BOOL estaVacio();											 //Dice si contiene items
			BOOL estaElegidoItem(unsigned posicion);         //Dice si el item de esa posicion est� seleccionado
			BOOL elegidoItem();										 //Dice si se ha seleccionado un item
			BOOL cambiaSeleccion();									 //Dice si se ha cambiado la posici�n del item actual
			BOOL estaVisibleItem(unsigned posicion);         //Dice si el item de esa posici�n esta visible

			void pintarItem(unsigned posicion);
			void pintarItem();
			void pintarAPartirDePosicion(unsigned posicion);
			void hacerVisibleItemActual();						 //Mueve la lista para que pueda verse el item actual

			BOOL insertarItem(char item[],unsigned posicion);//Inserta en la posici�n indicada
			BOOL insertarItem(char item[]);						 //Inserta item en la posici�n actual
			BOOL insertarAlFinalItem(char item[]);				 //Inserta el item al final de la lista
			BOOL insertarItem(TCadena &item,unsigned posicion);//Inserta en la posici�n indicada
			BOOL insertarItem(TCadena &item);						 //Inserta item en la posici�n actual
			BOOL insertarAlFinalItem(TCadena &item);				 //Inserta el item al final de la lista
			void borrarItem(unsigned posicion);  				 //Borra el item de la posicion indicada
			void borrarItem();                               //Borra el item actual
			void borrar();                                   //Borra todo el contenido de la lista
			BOOL copiarVectorCadenas(TVectorCadenas &cVCad); //Copia un vector de cadenas. Repintado obliga a que se repinte el contenido.

			BOOL seleccionarItem(unsigned posicion);         //Selecciona el item indicado
			BOOL seleccionarSiguienteItem(char caracter);    //Selecciona siguiente item que empiece por el caracter indicado
			BOOL deseleccionarItem(unsigned posicion);		 //Deselecciona el item indicado

			unsigned dimeNumItems();								 //Devuelve el n�mero de items que contiene
			TCadena & dimeItem(unsigned pos);				   //Devuelve el contenido del item de una posicion
			TCadena & dimeItem();								   //Devuelve el contenido del item actual
			TVectorCadenas & dimeItems();							//Devuelve el vector de items
			unsigned dimeMaxNumItemsVisibles(); 			    //Devuelve el n�mero de items que cogen en el recuadro de la lista
			unsigned dimeMaxNumCaracteresItemVisibles();     //Devuelve el n�mero de items que cogen en el recuadro de la lista
			unsigned dimeMaxLongItems();							 //Devuelve la longitud maxima de los items
			unsigned dimePosItemActual();		               //Devuelve la posicion del item actual
			unsigned dimePosDespX();							 //Devuelve la posicion de desplazamiento horizontal
			unsigned dimePosDespY();							 //Devuelve la posicion de desplazamiento vertical
			unsigned dimeMaxPosDespX();						 //Devuelve la maxima posicion de scroll horizontal
			BOOL     dimePosLimitadoresSeleccion(int &posX,int &posX1);  //Devuelve la posici�n de los limitadores de selecci�n en los par�metros de entrada. Devuelve FALSO si no recoge los limitadores.
			BOOL     dimePosRectanguloItemActual(int &posX,int &posY, int &posX1, int &posY1); //Devuelve la posici�n en pantalla del item actual, si est� visible. Si no est� visible devuelve falso.
			void     cambiarPosDespX(unsigned posicion); //Cambia la posici�n desde donde empieza a verse el texto horizontal
			void     cambiarPosDespY(unsigned posicion); //Cambia la posici�n desde donde empieza a verse el texto vertical
			void     cambiarPosItem(unsigned posicion);            //Cambia la posici�n actual del item
			void     cambiarItem(unsigned posicion,char nuevoItem[]);  //Cambia el contenido de un item
			void     cambiarItem(char nuevoItem[]);                    //Cambia el contenido del item actual
			void     cambiarItem(unsigned posicion,TCadena &nuevoItem);  //Cambia el contenido de un item
			void     cambiarItem(TCadena &nuevoItem);                    //Cambia el contenido del item actual
			void     elegirItem();												  //Mapea el evento de elegir item actual

			void     ordenar(BOOL creciente=CIERTO,unsigned posicion=0); //ordena los items de la lista

		protected:
			//Variables de proceso (solo lectura)

			BOOL m_elegidoItem;
			BOOL m_cambiaSeleccion;

			TVectorCadenas m_cItem;			 //items
			unsigned m_posItem;   			 //Posici�n del item actual
			unsigned m_posDespX;				 //Posici�n de desplazamiento horizontal
			unsigned m_posDespY;				 //Posici�n de desplazamiento vertical
			TCadena  m_cItemSeleccionado;  //Vector de indicadores de selecci�n de items
			unsigned m_numItems;           //n�mero de �tems

			unsigned m_maxPosDespX;					//M�ximo desplazamiento horizontal
			unsigned m_altoLinea;					//Separaci�n de l�neas de texto
			unsigned m_posItemAnt;					//Posici�n item anterior
			unsigned m_posDespYAnt;					//Posici�n anterior desplazamiento vertical
			unsigned m_posDespXAnt;					//Posici�n anterior desplazamiento horizontal
			unsigned m_maxCaracteresItemVisibles;//n�mero caracteres que cojen en una l�nea
			unsigned m_maxNumItemsVisibles;  	//n�mero de items que cogen en el recuadro de la lista
			unsigned m_longMaxCadenas;				//longitud m�xima de las cadenas del vector de cadenas


	};
#endif