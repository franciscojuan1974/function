#ifndef _WAV
#define _WAV

#include <stdio.h>
#include "util.h"

typedef struct{
	char           rID[4];
	unsigned long  tamWav;
	char           wID[4];
	char           fID[4];
	unsigned long  tamFormato;
	unsigned short tipoFormato;
	unsigned short numCanales;
	unsigned long  muestrasPorSeg;
	unsigned long  bytesPorSeg;
	unsigned short alineacionBloque;
	unsigned short bitsMuestra;
	char           dID[4];
	unsigned long  tamDatos;
}CAB_WAV;

typedef struct{
	char dID[4];
	unsigned long tamCabEtiqueta;
	unsigned long tipo;
}CAB_ETIQUETA_WAV;

typedef struct{
	char          lID[4];
	unsigned long tamCabList;
	char          iID[8];
	unsigned long tamCabDesc;
}CAB_INFO_WAV;

typedef struct{
	char cID[19];
	char otrosDatos[8];
	char tamVoc[3]; //en realidad es un n�mero de 3 bytes
	unsigned long muestrasPorSeg;
	char bitsMuestra;
	char numCanales;
	char otrosDatos1[6];
}CAB_VOC;


void transformarBuffer16a8(char[],unsigned *);
void transformarBuffer8a16(char[],unsigned *);
void sacaValoresInversosBuffer(char[],unsigned,unsigned);
void separaCanalesBuffer(char[],unsigned,char[],unsigned *,char[],unsigned *,unsigned);
void juntaCanalesBuffer(char[],unsigned *,char[],char[],unsigned);

void rellenaCabVoc(CAB_VOC *voc,unsigned long tamCanal, unsigned long frecuencia, unsigned short numCanales,unsigned bitsMuestra);
void rellenaCabEtiquetaWav(CAB_ETIQUETA_WAV *,unsigned long);
void rellenaCabInfoWav(CAB_INFO_WAV *,unsigned long);
void rellenaCabWav(CAB_WAV *,unsigned long,unsigned long,unsigned short,unsigned);

char esWavValido(CAB_WAV *);
char esWavCompatible(CAB_WAV *);

void imprimeDescripcionWavFichero(FILE *,char [],char []);
char cargaCabeceraWavFichero(CAB_WAV *,char []);

char transformaSmpAWav(char fichero[],char canal1[],char canal2[],unsigned short numCanales,unsigned long frecuencia,unsigned short bitsMuestra);
char transformaSmpAVoc(char fichero[],char canal1[],char canal2[],unsigned short numCanales,unsigned long frecuencia,unsigned short bitsMuestra);
char transformaWavASmp(char fichero[],char canal1[],char canal2[],char modo);



#endif